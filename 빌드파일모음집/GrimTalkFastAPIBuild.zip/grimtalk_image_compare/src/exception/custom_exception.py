class SimilarityMeasurementError(Exception):
    pass

class EmbeddingGenerationError(Exception):
    pass
