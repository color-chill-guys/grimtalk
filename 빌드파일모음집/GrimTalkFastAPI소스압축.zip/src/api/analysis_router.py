import logging
import math
import os
import traceback

import openai
from dotenv import load_dotenv
from fastapi import File, UploadFile, APIRouter
import numpy as np
from PIL import Image
import cv2
from skimage.metrics import structural_similarity as ssim

from src.common.base_response import BaseResponse
from src.common.base_response_status import BaseResponseStatus

router = APIRouter(prefix="/analysis", tags=["analysis"])

load_dotenv("backend-server.env")
# api_key = os.getenv("API_KEY")
api_key = "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"

def read_image(file: UploadFile) -> np.ndarray:
    """
    UploadFile을 읽어 numpy 배열 형태의 이미지로 변환.
    이미지 파일이 올바르지 않은 경우 None을 반환.
    """
    try:
        image = Image.open(file.file).convert("RGB")
        return np.array(image)
    except Exception as e:
        return None


def get_color_similarity(image1: np.ndarray, image2: np.ndarray) -> float:
    """
    색상 유사도를 개선한 함수.
    RGB 각 채널별 히스토그램을 비교한 후 평균을 계산.
    Bhattacharyya 거리 또는 Chi-Square 거리 기반.
    """
    similarity_scores = []

    for channel in range(3):  # R, G, B 각 채널별 비교
        hist1 = cv2.calcHist([image1], [channel], None, [256], [0, 256])
        hist2 = cv2.calcHist([image2], [channel], None, [256], [0, 256])

        # 히스토그램 정규화
        cv2.normalize(hist1, hist1)
        cv2.normalize(hist2, hist2)

        # Bhattacharyya 거리 계산 (값이 작을수록 유사)
        bhatta_distance = cv2.compareHist(hist1, hist2, cv2.HISTCMP_BHATTACHARYYA)
        similarity_scores.append(1 - bhatta_distance)  # 1에서 빼서 값이 클수록 유사하도록 변환

    # R, G, B 평균 유사도 반환
    return float(np.mean(similarity_scores))

def detect_lines(image: np.ndarray) -> int:
    """
    Hough 변환을 통해 직선을 검출하고,
    검출된 직선의 개수를 반환합니다.
    """
    # 1. Grayscale 변환
    gray = cv2.cvtColor(image, cv2.COLOR_RGB2GRAY)

    # 2. Canny Edge 검출
    edges = cv2.Canny(gray, 50, 150)

    # 3. Hough 변환을 이용한 선 검출
    #   - minLineLength, maxLineGap 등 파라미터를 상황에 맞게 조절하세요.
    lines = cv2.HoughLinesP(
        edges,
        rho=1,
        theta=np.pi / 180,
        threshold=50,
        minLineLength=30,
        maxLineGap=10
    )

    if lines is None:
        return 0  # 검출된 직선이 없으면 0 반환

    return len(lines)

def get_line_thickness_similarity(image1: np.ndarray, image2: np.ndarray) -> float:
    """
    선 굵기 유사도 계산: Canny 엣지 검출을 통해
    엣지 밀도를 비교하여 유사도를 반환.
    """
    gray1 = cv2.cvtColor(image1, cv2.COLOR_RGB2GRAY)
    gray2 = cv2.cvtColor(image2, cv2.COLOR_RGB2GRAY)

    edges1 = cv2.Canny(gray1, 100, 200)
    edges2 = cv2.Canny(gray2, 100, 200)

    # 엣지 픽셀 비율 계산 (0~1 범위로 정규화)
    density1 = np.sum(edges1 / 255) / edges1.size
    density2 = np.sum(edges2 / 255) / edges2.size

    # 유사도 계산 (음수 값 방지)
    similarity = max(0.0, 1 - abs(density1 - density2))

    return float(similarity)

def get_line_similarity(image1: np.ndarray, image2: np.ndarray) -> float:
    """
    선 굵기와 선 개수를 모두 고려한 '라인 유사도'를 계산하는 예시 함수.
    """
    # ----- (1) 선 굵기 유사도 -----
    line_thickness_sim = get_line_thickness_similarity(image1, image2)

    # ----- (2) 선 개수 유사도 -----
    count1 = detect_lines(image1)
    count2 = detect_lines(image2)

    # 두 이미지 간 선 개수 차이 비율(0~1 범위)
    # 예: 0이면 완전히 일치, 1이면 아주 크게 차이남
    if max(count1, count2) == 0:
        line_count_sim = 1.0 if count1 == count2 else 0.0
    else:
        diff_ratio = abs(count1 - count2) / max(count1, count2)
        # (가장 단순한 예) 개수 차이가 0이면 유사도 1, 개수 차이가 클수록 0에 가까움
        line_count_sim = max(0.0, 1 - diff_ratio)

    # ----- (3) 두 유사도 종합 -----
    combined_similarity = 0.3 * line_thickness_sim + 0.7 * line_count_sim

    return float(combined_similarity)

#--------------------------------------------------------------------------------
def sanitize_image(img: np.ndarray) -> np.ndarray:
    """
    NaN이나 Inf가 포함된 픽셀 값을 0~255 범위 내 적절한 값으로 치환합니다.
    유효하지 않은 입력(예: None, 빈 배열 등)은 1x1 검정색 이미지를 리턴합니다.
    """
    if img is None or not isinstance(img, np.ndarray) or img.size == 0:
        # 1x1짜리 검정색 이미지
        return np.zeros((1, 1, 3), dtype=np.uint8)

    sanitized = np.nan_to_num(img, nan=0.0, posinf=255.0, neginf=0.0)
    # 필요하다면 0~255 범위로 클램핑
    # sanitized = np.clip(sanitized, 0, 255).astype(np.uint8)
    return sanitized


def crop_to_content(img: np.ndarray, threshold=10) -> np.ndarray:
    """
    Canny 에지 등을 이용하여, 이미지에서 '선이 있는' 최소 바운딩 박스로 잘라냅니다.
    threshold: 크롭 시 경계를 여유 있게 잡기 위한 값.
    """
    # [1] img가 None이거나 비정상적이면 1x1 검정 이미지 반환
    if img is None or not isinstance(img, np.ndarray) or img.size == 0:
        return np.zeros((1, 1, 3), dtype=np.uint8)

    # [2] 혹시 흑백 이미지를 받았을 수도 있으니, 채널 수 확인 후 처리
    #     아래는 일단 RGB 이미지(3채널)를 가정
    if len(img.shape) == 2:
        # (h, w) -> (h, w, 1)로 확장하거나, 흑백 -> 3채널 변환
        img = cv2.cvtColor(img, cv2.COLOR_GRAY2RGB)

    # [3] 에지 검출
    gray = cv2.cvtColor(img, cv2.COLOR_RGB2GRAY)
    edges = cv2.Canny(gray, 50, 150)

    # [4] 에지 픽셀 좌표 찾기
    points = np.argwhere(edges > 0)
    if points.size == 0:
        # 선이 전혀 없으면 원본 그대로 반환 or 아주 작은 흰(검정) 배경
        return img

    # [5] 바운딩 박스 계산
    y_min, x_min = points.min(axis=0)
    y_max, x_max = points.max(axis=0)

    # [6] 클램핑
    y_min = max(y_min - threshold, 0)
    x_min = max(x_min - threshold, 0)
    y_max = min(y_max + threshold, img.shape[0])
    x_max = min(x_max + threshold, img.shape[1])

    # [7] 바운딩 박스 영역 크롭
    cropped = img[y_min:y_max, x_min:x_max]
    if cropped.size == 0:
        # 혹시 threshold 때문에 범위가 잘못되면 빈 배열이 될 수도 있음
        # 이 경우 1x1 검정 이미지 반환
        return np.zeros((1, 1, 3), dtype=np.uint8)

    return cropped


def custom_multiscale_ssim(img1: np.ndarray, img2: np.ndarray, levels: int = 3) -> float:
    """
    여러 해상도에서 SSIM을 계산하고 평균을 내는 방식으로
    멀티 스케일 SSIM을 근사합니다.
    """
    scores = []
    for level in range(levels):
        # SSIM 계산
        # ssim() 호출 시, data_range=0이면 NaN 가능하므로 max-min 확인 필요
        drange = max(1e-6, float(img1.max() - img1.min()))
        score, _ = ssim(img1, img2, full=True, data_range=drange)

        # NaN 방지
        if np.isnan(score):
            score = 0.0
        scores.append(score)

        # 다운샘플링: 이미지 크기가 너무 작아지지 않도록 체크
        if min(img1.shape) < 16 or min(img2.shape) < 16:
            break

        # cv2.pyrDown을 사용하여 이미지를 반 크기로 축소
        img1 = cv2.pyrDown(img1)
        img2 = cv2.pyrDown(img2)

    mean_score = np.mean(scores)
    if np.isnan(mean_score):
        mean_score = 0.0

    return float(mean_score)


def get_structure_similarity_multiscale(image1: np.ndarray, image2: np.ndarray) -> float:
    """
    두 이미지의 구조적 유사도를 멀티 스케일 방식으로 계산.
    에러(예외) 발생 없이, 잘못된 입력은 최대한 안전하게 처리.
    """
    # 1) NaN/Inf 제거 & 유효성 처리
    image1 = sanitize_image(image1)
    image2 = sanitize_image(image2)

    # 2) 선이 있는 영역만 크롭 (배경 제거 효과)
    image1_cropped = crop_to_content(image1)
    image2_cropped = crop_to_content(image2)

    # 3) 다시 한 번 sanitize (크롭 결과가 빈 배열이 되었을 수도 있으니)
    image1_cropped = sanitize_image(image1_cropped)
    image2_cropped = sanitize_image(image2_cropped)

    # 4) 그레이 변환
    gray1 = cv2.cvtColor(image1_cropped, cv2.COLOR_RGB2GRAY)
    gray2 = cv2.cvtColor(image2_cropped, cv2.COLOR_RGB2GRAY)

    # 5) 크기가 다르면 resize
    if gray1.shape != gray2.shape:
        # 혹시 resize가 불가능할 정도로 이상하다면 예외 없이 안전 처리
        try:
            gray2 = cv2.resize(gray2, (gray1.shape[1], gray1.shape[0]))
        except Exception:
            # 문제가 생기면 1x1 검정 이미지로 대체
            gray2 = np.zeros((gray1.shape[0], gray1.shape[1]), dtype=np.uint8)

    # 6) SSIM 계산
    score = custom_multiscale_ssim(gray1, gray2, levels=3)
    if np.isnan(score):
        score = 0.0

    return float(score)

#----------------------------------------------------------------------------------------------
# # [CHANGED] NaN/Inf 제거용 유틸 함수 추가
# def sanitize_image(img: np.ndarray) -> np.ndarray:
#     """
#     NaN이나 Inf가 포함된 픽셀 값을 0~255 범위 내 적절한 값으로 치환합니다.
#     """
#     # np.nan_to_num을 사용해 NaN은 0, +Inf는 255, -Inf는 0 등으로 처리
#     return np.nan_to_num(img, nan=0.0, posinf=255.0, neginf=0.0)
#
#
# # [CHANGED] 단색(모든 픽셀이 동일)인지 체크하는 함수
# def is_uniform_image(img: np.ndarray) -> bool:
#     return (img.max() == img.min())

# def custom_multiscale_ssim(img1: np.ndarray, img2: np.ndarray, levels: int = 3) -> float:
#     """
#     여러 해상도에서 SSIM을 계산하고 평균을 내는 방식으로
#     멀티 스케일 SSIM을 근사합니다.
#     """
#     scores = []
#     for level in range(levels):
#         # [CHANGED] ssim 계산 시 NaN이 발생할 수 있으므로 예외 처리
#         # full=True는 (score, diff_map)을 반환
#         score, _ = ssim(img1, img2, full=True, data_range=img1.max() - img1.min())
#
#         # [CHANGED] 만약 NaN이면(계산 과정 중 문제) 0으로 대체
#         if np.isnan(score):
#             score = 0.0
#
#         scores.append(score)
#
#         # 다운샘플링: 이미지 크기가 너무 작아지지 않도록 체크
#         if min(img1.shape) < 16 or min(img2.shape) < 16:
#             break
#
#         # cv2.pyrDown을 사용하여 이미지를 반 크기로 축소
#         img1 = cv2.pyrDown(img1)
#         img2 = cv2.pyrDown(img2)
#
#     # [CHANGED] 혹시 평균 후에도 NaN이 생길 경우 대비(실제론 거의 없겠지만)
#     mean_score = np.mean(scores)
#     if np.isnan(mean_score):
#         mean_score = 0.0
#
#     return float(mean_score)
#
#
# def get_structure_similarity_multiscale(image1: np.ndarray, image2: np.ndarray) -> float:
#     """
#     두 이미지의 구조적 유사도를 멀티 스케일 방식으로 계산합니다.
#     """
#     # [CHANGED] 1) NaN/Inf 제거
#     image1 = sanitize_image(image1)
#     image2 = sanitize_image(image2)
#
#     # 그레이 스케일 변환
#     gray1 = cv2.cvtColor(image1, cv2.COLOR_RGB2GRAY)
#     gray2 = cv2.cvtColor(image2, cv2.COLOR_RGB2GRAY)
#
#     # [CHANGED] 2) 단색 이미지 여부 확인 -> 그대로 계산 시 SSIM 분모가 0이 될 수 있음
#     if is_uniform_image(gray1) and is_uniform_image(gray2):
#         # 같은 단색이면 SSIM을 1.0, 다른 단색이면 0.0 등으로 처리
#         if gray1[0, 0] == gray2[0, 0]:
#             return 1.0
#         else:
#             return 0.0
#
#     # 이미지 크기가 다르면 첫 번째 이미지에 맞춰 resize
#     if gray1.shape != gray2.shape:
#         gray2 = cv2.resize(gray2, (gray1.shape[1], gray1.shape[0]))
#
#     # [CHANGED] 3) 커스텀 멀티 스케일 SSIM 계산 -> NaN 발생 시 0 처리
#     score = custom_multiscale_ssim(gray1, gray2, levels=3)
#     if np.isnan(score):
#         score = 0.0
#
#     return float(score)
#----------------------------------------------------------------------------------------------
# def custom_multiscale_ssim(img1: np.ndarray, img2: np.ndarray, levels: int = 3) -> float:
#     """
#     여러 해상도에서 SSIM을 계산하고 평균을 내는 방식으로
#     멀티 스케일 SSIM을 근사합니다.
#     """
#     scores = []
#     for level in range(levels):
#         score, _ = ssim(img1, img2, full=True, data_range=img1.max() - img1.min())
#         scores.append(score)
#
#         # 다운샘플링: 이미지 크기가 너무 작아지지 않도록 체크
#         if min(img1.shape) < 16 or min(img2.shape) < 16:
#             break
#
#         # cv2.pyrDown을 사용하여 이미지를 반 크기로 축소
#         img1 = cv2.pyrDown(img1)
#         img2 = cv2.pyrDown(img2)
#
#     return np.mean(scores)
#
# def get_structure_similarity_multiscale(image1: np.ndarray, image2: np.ndarray) -> float:
#     """
#     두 이미지의 구조적 유사도를 멀티 스케일 방식으로 계산합니다.
#     """
#     # 그레이 스케일 변환
#     gray1 = cv2.cvtColor(image1, cv2.COLOR_RGB2GRAY)
#     gray2 = cv2.cvtColor(image2, cv2.COLOR_RGB2GRAY)
#
#     # 이미지 크기가 다르면 첫 번째 이미지에 맞춰 resize
#     if gray1.shape != gray2.shape:
#         gray2 = cv2.resize(gray2, (gray1.shape[1], gray1.shape[0]))
#
#     # 커스텀 멀티 스케일 SSIM 계산
#     score = custom_multiscale_ssim(gray1, gray2, levels=3)
#     return float(score)

# def get_feedback_comment(score: int, category: str) -> str:
#     """
#     유사도 점수에 따라 강사의 피드백을 반환하는 함수.
#     """
#     # 🎨 색상 관련 피드백
#     if category == "color":
#         if score >= 90:
#             return (
#                 "색상이 거의 완벽하게 일치하네요! 색의 선택과 사용이 매우 정확합니다. "
#                 "색상 감각이 뛰어나고, 원본의 색감을 잘 분석하여 표현했어요. "
#                 "이제 미세한 색의 톤 변화나 명암을 조금 더 신경 써서 디테일을 추가하면 더욱 완벽한 색상을 표현할 수 있습니다."
#             )
#         elif score >= 80:
#             return (
#                 "색상이 대부분 비슷하지만, 미묘한 차이가 있어요. 전반적인 색조는 잘 맞췄지만, "
#                 "일부 영역에서 톤이나 채도가 약간 다릅니다. 색을 더 정확하게 맞추기 위해, "
#                 "색상 추출 도구를 활용하여 원본과 비교하거나, 색 혼합 연습을 해보는 것도 좋습니다!"
#             )
#         elif score >= 70:
#             return (
#                 "색상이 꽤 유사하지만, 전반적인 밝기나 채도가 약간 다를 수 있어요. "
#                 "색을 비교할 때 RGB 값이나 HSV 값을 활용해서 보다 정교한 색 조절을 연습해 보세요. "
#                 "특히 빛과 그림자가 색상에 어떻게 영향을 주는지 연구하면 도움이 될 거예요."
#             )
#         elif score >= 50:
#             return (
#                 "색상 차이가 꽤 납니다. 비슷한 색을 사용하려 했지만, 색의 밝기나 채도가 원본과 다를 수 있습니다. "
#                 "색상을 선택할 때, 색의 명도와 채도를 조절하는 연습을 해보면 좋겠습니다. "
#                 "또한 색상 혼합을 통해 원하는 색을 만들어 보는 연습도 필요해요."
#             )
#         elif score >= 30:
#             return (
#                 "색상이 많이 다릅니다. 색상 감각을 기르기 위해, 색을 직접 비교하는 연습을 해보는 것이 좋습니다. "
#                 "예를 들어, 색상 팔레트를 만들어 원본 색과 비교해보거나, 색을 추출해서 조합하는 연습을 해보세요."
#             )
#         else:
#             return (
#                 "색감이 전혀 다릅니다. 색상의 기본적인 톤과 분위기를 먼저 분석한 후 다시 조정해 보세요. "
#                 "색상을 올바르게 선택하는 연습을 더 많이 해보는 것이 중요하며, 색의 역할과 색조 변화를 이해하면 "
#                 "더욱 자연스러운 색 표현이 가능할 것입니다."
#             )
#
#     # ✏️ 선 굵기 관련 피드백
#     elif category == "line":
#         if score >= 90:
#             return (
#                 "선 굵기가 완벽하게 일치합니다! 선을 다루는 능력이 뛰어나고, 세밀한 조절이 매우 정확합니다. "
#                 "일정한 필압을 유지하며 선을 그리는 능력이 훌륭하네요. "
#                 "이제 선의 흐름과 자연스러움까지 신경 쓴다면 더욱 완벽한 표현이 가능할 것입니다!"
#             )
#         elif score >= 80:
#             return (
#                 "선 굵기가 대체로 비슷하지만, 일부 구간에서 굵기 차이가 조금씩 보입니다. "
#                 "선의 끝부분이나 곡선 부분에서 굵기가 변하는 경향이 있는데, "
#                 "이를 더 정교하게 조절하면 더욱 자연스러운 선을 표현할 수 있어요!"
#             )
#         elif score >= 70:
#             return (
#                 "선 굵기가 유사하긴 하지만, 일부 선이 더 두껍거나 얇게 표현되었습니다. "
#                 "특히 일정한 필압을 유지하는 연습을 하면 더 균일한 선을 그릴 수 있어요. "
#                 "또한 브러시 설정을 조절하여 선의 굵기를 더 정확하게 표현하는 방법도 익혀보세요."
#             )
#         elif score >= 50:
#             return (
#                 "선 굵기의 차이가 제법 있습니다. 선을 일정한 두께로 유지하기 위해서는 "
#                 "필압을 일정하게 조절하는 연습을 해보는 것이 중요합니다. "
#                 "속도를 조절하며 선을 천천히 그려보는 것도 도움이 될 거예요."
#             )
#         elif score >= 30:
#             return (
#                 "선이 너무 두껍거나 얇아졌어요. 선을 그릴 때의 힘을 조절하면서 균일한 두께를 만들어 보세요. "
#                 "일정한 힘을 유지하는 연습과 함께, 다양한 두께의 선을 그려보는 연습도 필요합니다."
#             )
#         else:
#             return (
#                 "선 굵기가 완전히 다릅니다. 일정한 두께를 유지하는 연습이 필요해요. "
#                 "필압을 조절하면서 선을 부드럽게 그리는 연습을 하면 선의 균일성이 향상될 거예요."
#             )
#
#     # 🏗️ 구조 유사도 관련 피드백
#     elif category == "structure":
#         if score >= 90:
#             return (
#                 "형태가 완벽하게 일치합니다! 비율과 윤곽선이 매우 정밀하며, 세밀한 묘사력까지 훌륭합니다. "
#                 "이제 미세한 디테일을 더욱 살리고, 질감을 표현하는 연습을 해보면 더욱 완성도 높은 결과물을 만들 수 있을 거예요!"
#             )
#         elif score >= 80:
#             return (
#                 "형태가 거의 비슷하지만, 세부적인 부분에서 약간의 차이가 있습니다. "
#                 "예를 들어, 작은 디테일이나 각도에서 차이가 나타날 수 있어요. "
#                 "전체적인 형태 분석을 조금 더 신경 쓰면 완벽한 결과물을 얻을 수 있습니다."
#             )
#         elif score >= 70:
#             return (
#                 "형태가 대체로 비슷하지만, 일부 비율에서 차이가 있습니다. "
#                 "객관적으로 형태를 비교하는 훈련을 하면 더욱 정확한 구조를 잡을 수 있어요. "
#                 "기본적인 윤곽선을 맞추는 연습을 해보는 것도 좋습니다."
#             )
#         elif score >= 50:
#             return (
#                 "구조적으로 차이가 있어요. 주요 윤곽선을 다시 확인하고, 기본 비율을 맞추는 연습이 필요합니다. "
#                 "전체적인 형태의 조화를 맞추는 연습을 진행해 보세요!"
#             )
#         elif score >= 30:
#             return (
#                 "형태가 많이 달라졌어요. 전체적인 비율과 구성을 다시 점검하고, 선을 맞추는 연습이 필요합니다. "
#                 "기본 도형을 이용해 구조를 잡아보는 연습을 해보세요."
#             )
#         else:
#             return (
#                 "구조가 완전히 다릅니다. 기본 형태부터 다시 연습해 보세요! "
#                 "비율과 형태를 잡는 연습을 반복하면서 기본적인 틀을 확립하는 것이 중요합니다."
#             )
#
#     return "유사도 점수가 확인되지 않았습니다."  # 예외 처리

def get_feedback_comment(score: int, category: str) -> str:
    """
    유사도 점수에 따라 강사의 피드백을 반환하는 함수.
    선 카테고리('line')는 선 굵기 + 선 개수를 종합한 유사도 점수를 가정합니다.
    """
    # 🎨 색상 관련 피드백
    if category == "color":
        if score >= 90:
            return (
                "색상이 거의 완벽하게 일치하네요! 색의 선택과 사용이 매우 정확합니다. "
                "색상 감각이 뛰어나고, 원본의 색감을 잘 분석하여 표현했어요. "
                "이제 미세한 색의 톤 변화나 명암을 조금 더 신경 써서 디테일을 추가하면 더욱 완벽한 색상을 표현할 수 있습니다."
            )
        elif score >= 80:
            return (
                "색상이 대부분 비슷하지만, 미묘한 차이가 있어요. 전반적인 색조는 잘 맞췄지만, "
                "일부 영역에서 톤이나 채도가 약간 다릅니다. 색을 더 정확하게 맞추기 위해, "
                "색상 추출 도구를 활용하여 원본과 비교하거나, 색 혼합 연습을 해보는 것도 좋습니다!"
            )
        elif score >= 70:
            return (
                "색상이 꽤 유사하지만, 전반적인 밝기나 채도가 약간 다를 수 있어요. "
                "색을 비교할 때 RGB 값이나 HSV 값을 활용해서 보다 정교한 색 조절을 연습해 보세요. "
                "특히 빛과 그림자가 색상에 어떻게 영향을 주는지 연구하면 도움이 될 거예요."
            )
        elif score >= 50:
            return (
                "색상 차이가 꽤 납니다. 비슷한 색을 사용하려 했지만, 색의 밝기나 채도가 원본과 다를 수 있습니다. "
                "색상을 선택할 때, 색의 명도와 채도를 조절하는 연습을 해보면 좋겠습니다. "
                "또한 색상 혼합을 통해 원하는 색을 만들어 보는 연습도 필요해요."
            )
        elif score >= 30:
            return (
                "색상이 많이 다릅니다. 색상 감각을 기르기 위해, 색을 직접 비교하는 연습을 해보는 것이 좋습니다. "
                "예를 들어, 색상 팔레트를 만들어 원본 색과 비교해보거나, 색을 추출해서 조합하는 연습을 해보세요."
            )
        else:
            return (
                "색감이 전혀 다릅니다. 색상의 기본적인 톤과 분위기를 먼저 분석한 후 다시 조정해 보세요. "
                "색상을 올바르게 선택하는 연습을 더 많이 해보는 것이 중요하며, 색의 역할과 색조 변화를 이해하면 "
                "더욱 자연스러운 색 표현이 가능할 것입니다."
            )

    # ✏️ 선(굵기+개수) 관련 피드백
    elif category == "line":
        # 여기서는 'score'가 '선 굵기' + '선 개수' 종합 유사도라고 가정합니다.
        if score >= 90:
            return (
                "선의 굵기와 개수가 모두 원본과 거의 완벽하게 일치합니다! "
                "아주 섬세한 필압 조절과 선 배치 능력을 갖추셨네요. "
                "이제 선을 좀 더 자연스럽게 이어주거나 흐름에 신경 쓰시면 더욱 완벽한 표현이 가능할 거예요!"
            )
        elif score >= 80:
            return (
                "선의 굵기와 개수가 대부분 비슷하지만, 일부 구간에서 약간의 차이가 보여요. "
                "특히 선이 모이는 부분에서 조금 더 세밀하게 두께와 배치를 조절해 주시면 좋겠습니다. "
                "선이 너무 많이 겹치거나 비어 보이지 않는지 점검해 보세요!"
            )
        elif score >= 70:
            return (
                "선의 굵기나 개수가 어느 정도 유사하긴 하지만, 특정 부분에서 오차가 드러납니다. "
                "필압이 일정하지 않거나, 선을 필요 이상으로 많이(또는 적게) 그릴 수 있어요. "
                "어느 부분에서 선이 너무 많거나 부족한지, 굵기는 적절히 유지되는지 확인해보면 좋겠습니다."
            )
        elif score >= 50:
            return (
                "선의 굵기나 개수가 원본과 꽤 다르게 느껴집니다. "
                "선의 흐름을 간단히 스케치한 뒤, 필요한 부분에만 선을 강조해 보는 연습을 해보세요. "
                "필압과 선 개수를 함께 조절하는 습관을 기르면 더욱 안정된 선 표현이 가능합니다."
            )
        elif score >= 30:
            return (
                "선의 굵기나 개수 모두 전반적으로 차이가 큽니다. "
                "원본의 선이 어디에, 얼마나 있는지를 먼저 파악한 뒤 그 비율대로 연습해 보세요. "
                "처음에는 선을 얇고 적게 그려가며 정확한 위치와 개수를 맞추는 연습부터 시작하는 것도 좋습니다."
            )
        else:
            return (
                "원본과는 전혀 다른 선 표현입니다. 선의 흐름, 굵기, 개수를 전반적으로 다시 점검해보세요. "
                "간단한 도형 위주로 형태를 잡은 뒤, 필요한 선만 추가하는 습관을 길러보시길 권장드립니다. "
                "필압 조절과 선의 밀도를 한 번에 익히려 하기보다는 단계적으로 연습해 보세요."
            )

    # 🏗️ 구조 유사도 관련 피드백
    elif category == "structure":
        if score >= 90:
            return (
                "형태가 완벽하게 일치합니다! 비율과 윤곽선이 매우 정밀하며, 세밀한 묘사력까지 훌륭합니다. "
                "이제 미세한 디테일을 더욱 살리고, 질감을 표현하는 연습을 해보면 더욱 완성도 높은 결과물을 만들 수 있을 거예요!"
            )
        elif score >= 80:
            return (
                "형태가 거의 비슷하지만, 세부적인 부분에서 약간의 차이가 있습니다. "
                "예를 들어, 작은 디테일이나 각도에서 차이가 나타날 수 있어요. "
                "전체적인 형태 분석을 조금 더 신경 쓰면 완벽한 결과물을 얻을 수 있습니다."
            )
        elif score >= 70:
            return (
                "형태가 대체로 비슷하지만, 일부 비율에서 차이가 있습니다. "
                "객관적으로 형태를 비교하는 훈련을 하면 더욱 정확한 구조를 잡을 수 있어요. "
                "기본적인 윤곽선을 맞추는 연습을 해보는 것도 좋습니다."
            )
        elif score >= 50:
            return (
                "구조적으로 차이가 있어요. 주요 윤곽선을 다시 확인하고, 기본 비율을 맞추는 연습이 필요합니다. "
                "전체적인 형태의 조화를 맞추는 연습을 진행해 보세요!"
            )
        elif score >= 30:
            return (
                "형태가 많이 달라졌어요. 전체적인 비율과 구성을 다시 점검하고, 선을 맞추는 연습이 필요합니다. "
                "기본 도형을 이용해 구조를 잡아보는 연습을 해보세요."
            )
        else:
            return (
                "구조가 완전히 다릅니다. 기본 형태부터 다시 연습해 보세요! "
                "비율과 형태를 잡는 연습을 반복하면서 기본적인 틀을 확립하는 것이 중요합니다."
            )

    return "유사도 점수가 확인되지 않았습니다."


def generate_gpt_feedback(color_similarity: int, line_similarity: int, structure_similarity: int) -> str:
    """
    OpenAI GPT API를 사용하여 피드백 생성
    """
    client = openai.OpenAI(api_key=api_key)  # 최신 방식으로 클라이언트 객체 생성

    prompt = f"""
    학생이 강사의 그림을 따라 그린 결과를 분석한 데이터입니다.
    - 색상 유사도: {color_similarity}%
    - 선 굵기 유사도: {line_similarity}%
    - 구조 유사도: {structure_similarity}%

    위의 정보를 바탕으로 학생이 기죽지 않으면서도 발전할 수 있도록 전체적인 피드백을 제공해주세요.
    너무 단순한 칭찬보다는 개선할 부분도 포함하여 설명해주세요.
    너무 길지 않게 3줄 정도로 명확하고 깔끔하게 설명해주세요.
    반말 말고 존대말로 설명해주세요.
    모든 연령이 알아들을 수 있게 설명해주세요.

    피드백:
    """

    response = client.chat.completions.create(
        model="gpt-4",
        messages=[
            {"role": "system", "content": "너는 미술 선생님으로서 학생들에게 그림 피드백을 제공하는 역할입니다."},
            {"role": "user", "content": prompt}
        ]
    )

    feedback = response.choices[0].message.content
    return feedback.strip()


@router.post("/compare-images")
async def compare_images(teacher_file: UploadFile = File(...), student_file: UploadFile = File(...)):
    if not api_key:
        return BaseResponse.base(BaseResponseStatus.API_KEY_ERROR)

    img1 = read_image(teacher_file)
    img2 = read_image(student_file)

    if img1 is None or img2 is None:
        return BaseResponse.base(BaseResponseStatus.INVALID_IMAGE_INPUT)

    try:
        color_similarity = math.trunc(get_color_similarity(img1, img2) * 100)
    except Exception as e:
        logging.exception(f"error message={traceback.format_exc()}")
        return BaseResponse.base(BaseResponseStatus.COLOR_SIMILARITY_ERROR, result={"detail": str(e)})

    try:
        line_similarity = math.trunc(get_line_similarity(img1, img2) * 100)
    except Exception as e:
        logging.exception(f"error message={traceback.format_exc()}")
        return BaseResponse.base(BaseResponseStatus.EDGE_MEASUREMENT_ERROR, result={"detail": str(e)})

    try:
        structure_similarity = math.trunc(get_structure_similarity_multiscale(img1, img2) * 100)
    except Exception as e:
        logging.exception(f"error message={traceback.format_exc()}")
        return BaseResponse.base(BaseResponseStatus.STRUCTURE_MEASUREMENT_ERROR, result={"detail": str(e)})

    result = {
        "color_similarity": color_similarity,
        "color_comment": get_feedback_comment(color_similarity, "color"),
        "line_thickness_similarity": line_similarity,
        "line_comment": get_feedback_comment(line_similarity, "line"),
        "structure_similarity": structure_similarity,
        "structure_comment": get_feedback_comment(structure_similarity, "structure"),
        "overall_feedback": generate_gpt_feedback(color_similarity, line_similarity, structure_similarity),
    }

    return BaseResponse.base(BaseResponseStatus.SUCCESS, result=result)
