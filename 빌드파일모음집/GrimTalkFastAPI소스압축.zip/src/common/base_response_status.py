from enum import Enum

class BaseResponseStatus(Enum):
    SUCCESS = (True, 200, "요청에 성공하였습니다.")
    INTERNAL_SERVER_ERROR = (False, 500, "서버에 오류가 발생했습니다.")
    COLOR_SIMILARITY_ERROR = (False, 6001, "색상 유사도 측정 중 오류가 발생했습니다.")
    EDGE_MEASUREMENT_ERROR = (False, 6002, "엣지 유사도 측정 중 오류가 발생했습니다.")
    STRUCTURE_MEASUREMENT_ERROR = (False, 6003, "구조 유사도 측정 중 오류가 발생했습니다.")
    EMBEDDING_GENERATION_ERROR = (False, 6004, "임베딩 생성 중 오류가 발생했습니다.")
    INVALID_IMAGE_INPUT = (False, 4001, "이미지 입력이 올바르지 않습니다.")
    API_KEY_ERROR = (False, 5003, "API_KEY가 설정되지 않았습니다.")

    def __init__(self, is_success: bool, code: int, message: str):
        self.is_success = is_success
        self.code = code
        self.message = message
